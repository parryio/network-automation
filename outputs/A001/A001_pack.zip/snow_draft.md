# ServiceNow Draft

**Summary**: Offline triage completed for A001 on rtr-site001-core.

## Blast Radius
Alarm A001 appears confined to rtr-site001-core at site001. No adjacent core links show correlated errors in offline dataset.

## Suggested Next Steps
1. Collect interface counters (show interface).
2. Review recent changes (git diff / change log).
3. If persists, schedule maintenance window to replace optics.
